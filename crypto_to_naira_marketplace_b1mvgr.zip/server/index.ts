/**
 * MeekHub backend — Paystack bank transfer payout server
 *
 * Routes:
 *   GET  /health                  — liveness check
 *   GET  /banks                   — list Nigerian banks from Paystack
 *   POST /verify-account          — resolve account name from NUBAN + bank code
 *   POST /payout                  — initiate instant NGN bank transfer
 *
 * Env vars (add to .env):
 *   PAYSTACK_SECRET_KEY=sk_test_...
 */

import express from 'express'

const app = express()
app.use(express.json())

const PAYSTACK_BASE = 'https://api.paystack.co'

function paystackHeaders() {
  const key = process.env.PAYSTACK_SECRET_KEY
  if (!key) throw new Error('PAYSTACK_SECRET_KEY is not set in .env')
  return {
    Authorization: `Bearer ${key}`,
    'Content-Type': 'application/json',
  }
}

// ── Health ─────────────────────────────────────────────────────
app.get('/health', (_req, res) => {
  res.json({ ok: true })
})

// ── List banks ─────────────────────────────────────────────────
app.get('/banks', async (_req, res) => {
  if (!process.env.PAYSTACK_SECRET_KEY) {
    // Return empty so the frontend keeps its built-in list
    res.json([])
    return
  }
  try {
    const r = await fetch(`${PAYSTACK_BASE}/bank?currency=NGN&perPage=200`, {
      headers: paystackHeaders(),
    })
    const data = await r.json() as { status: boolean; data: unknown }
    if (!data.status) {
      res.json([])
      return
    }
    res.json(data.data)
  } catch {
    res.json([])
  }
})

// ── Verify account name ────────────────────────────────────────
app.post('/verify-account', async (req, res) => {
  const { account_number, bank_code } = req.body as {
    account_number?: string
    bank_code?: string
  }
  if (!account_number || !bank_code) {
    res.status(400).json({ error: 'account_number and bank_code are required' })
    return
  }
  try {
    const url = `${PAYSTACK_BASE}/bank/resolve?account_number=${account_number}&bank_code=${bank_code}`
    const r = await fetch(url, { headers: paystackHeaders() })
    const data = await r.json() as { status: boolean; data?: { account_name: string }; message?: string }
    if (!data.status) {
      res.status(400).json({ error: data.message ?? 'Could not resolve account' })
      return
    }
    res.json({ account_name: data.data?.account_name ?? '' })
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown error'
    res.status(500).json({ error: msg })
  }
})

// ── Initiate payout ────────────────────────────────────────────
app.post('/payout', async (req, res) => {
  const { account_number, bank_code, account_name, amount_ngn, coin, tx_hash, order_ref } =
    req.body as {
      account_number?: string
      bank_code?: string
      account_name?: string
      amount_ngn?: number
      coin?: string
      tx_hash?: string
      order_ref?: string
    }

  if (!account_number || !bank_code || !account_name || !amount_ngn) {
    res.status(400).json({ error: 'Missing required payout fields' })
    return
  }

  try {
    // Step 1 — create a transfer recipient
    const recipientRes = await fetch(`${PAYSTACK_BASE}/transferrecipient`, {
      method: 'POST',
      headers: paystackHeaders(),
      body: JSON.stringify({
        type: 'nuban',
        name: account_name,
        account_number,
        bank_code,
        currency: 'NGN',
      }),
    })
    const recipientData = await recipientRes.json() as {
      status: boolean
      data?: { recipient_code: string }
      message?: string
    }
    if (!recipientData.status) {
      res.status(400).json({ error: recipientData.message ?? 'Failed to create recipient' })
      return
    }
    const recipient_code = recipientData.data!.recipient_code

    // Step 2 — initiate the transfer (amount in kobo = NGN × 100)
    const transferRes = await fetch(`${PAYSTACK_BASE}/transfer`, {
      method: 'POST',
      headers: paystackHeaders(),
      body: JSON.stringify({
        source: 'balance',
        amount: Math.round(amount_ngn * 100),
        recipient: recipient_code,
        reason: `MeekHub payout — ${coin ?? 'crypto'} sale${order_ref ? ` (${order_ref})` : ''}${tx_hash ? ` tx:${tx_hash.slice(0, 10)}` : ''}`,
      }),
    })
    const transferData = await transferRes.json() as {
      status: boolean
      data?: { transfer_code: string; status: string }
      message?: string
    }
    if (!transferData.status) {
      res.status(400).json({ error: transferData.message ?? 'Transfer initiation failed' })
      return
    }

    res.json({
      transfer_code: transferData.data?.transfer_code,
      status: transferData.data?.status,
    })
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown error'
    res.status(500).json({ error: msg })
  }
})

const PORT = process.env.PORT ?? 3001
app.listen(PORT, () => {
  console.log(`MeekHub payout server running on port ${PORT}`)
})
