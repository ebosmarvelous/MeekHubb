import { useState, useEffect, useCallback } from 'react'
import { useAccount, useReadContract, useSwitchChain } from 'wagmi'
import { ConnectKitButton } from 'connectkit'
import { erc20Abi } from 'viem'
import { TokenUSDC, TokenETH } from '@web3icons/react'
import {
  ArrowDown,
  RefreshCw,
  ShieldCheck,
  Zap,
  Clock,
  ChevronDown,
  Wallet,
  AlertTriangle,
} from 'lucide-react'
import { getUsdc } from '@/onchain-facts'
import { Amount, usdcDecimalsFor } from '@/onchain-money'
import OrderSheet from './OrderSheet'

// ── Coin icons ─────────────────────────────────────────────────
function BTCIcon({ size = 32 }: { size?: number }) {
  return (
    <span
      className="mono flex shrink-0 items-center justify-center rounded-full font-bold text-white"
      style={{ width: size, height: size, fontSize: size * 0.38, background: '#f7931a' }}
    >
      ₿
    </span>
  )
}
function USDTIcon({ size = 32 }: { size?: number }) {
  return (
    <span
      className="mono flex shrink-0 items-center justify-center rounded-full font-bold text-white"
      style={{ width: size, height: size, fontSize: size * 0.36, background: '#26a17b' }}
    >
      T
    </span>
  )
}

// ── Types ──────────────────────────────────────────────────────
type CoinId = 'usdc' | 'usdt' | 'eth' | 'btc'
interface Coin {
  id: CoinId
  label: string
  fullName: string
  icon: (size?: number) => React.ReactNode
  isUsdc: boolean
}

const COINS: Coin[] = [
  {
    id: 'usdc',
    label: 'USDC',
    fullName: 'USD Coin',
    icon: (size = 32) => <TokenUSDC variant="branded" size={size} />,
    isUsdc: true,
  },
  {
    id: 'usdt',
    label: 'USDT',
    fullName: 'Tether USD',
    icon: (size = 32) => <USDTIcon size={size} />,
    isUsdc: false,
  },
  {
    id: 'eth',
    label: 'ETH',
    fullName: 'Ethereum',
    icon: (size = 32) => <TokenETH variant="branded" size={size} />,
    isUsdc: false,
  },
  {
    id: 'btc',
    label: 'BTC',
    fullName: 'Bitcoin',
    icon: (size = 32) => <BTCIcon size={size} />,
    isUsdc: false,
  },
]

// ── Demo rates (NGN per 1 coin) ────────────────────────────────
const NGN_RATES: Record<CoinId, number> = {
  usdc: 1350,
  usdt: 1345,
  eth: 1350 * 3450,
  btc: 1350 * 68000,
}

const TARGET_CHAIN_ID = 5042002

// ── Styles ─────────────────────────────────────────────────────
const card: React.CSSProperties = {
  background: 'rgba(255,255,255,0.88)',
  backdropFilter: 'blur(28px) saturate(180%)',
  WebkitBackdropFilter: 'blur(28px) saturate(180%)',
  border: '1px solid rgba(18,45,69,0.09)',
  boxShadow: '0 4px 32px rgba(18,45,69,0.07)',
}

const field: React.CSSProperties = {
  background: 'rgba(18,45,69,0.04)',
  border: '1px solid rgba(18,45,69,0.08)',
  borderRadius: '16px',
}

// ── Coin dropdown ──────────────────────────────────────────────
function CoinPicker({
  selected,
  onSelect,
}: {
  selected: CoinId
  onSelect: (id: CoinId) => void
}) {
  const [open, setOpen] = useState(false)
  const coin = COINS.find((c) => c.id === selected)!

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-2 rounded-2xl px-3 py-2 text-sm font-semibold transition-colors hover:bg-black/5"
        style={{ color: 'var(--ink)' }}
      >
        {coin.icon(26)}
        <span className="leading-tight">
          {coin.label}
          <span className="block text-[10px] font-normal" style={{ color: 'var(--muted)' }}>
            {coin.fullName}
          </span>
        </span>
        <ChevronDown
          className="ml-0.5 size-3.5"
          style={{
            color: 'var(--subtle)',
            transform: open ? 'rotate(180deg)' : undefined,
            transition: 'transform 150ms',
          }}
        />
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div
            className="absolute left-0 top-full z-20 mt-1.5 w-48 overflow-hidden rounded-2xl py-1.5"
            style={card}
          >
            {COINS.map((c) => (
              <button
                key={c.id}
                onClick={() => { onSelect(c.id); setOpen(false) }}
                className="flex w-full items-center gap-2.5 px-3.5 py-2.5 transition-colors hover:bg-black/5"
                style={{
                  background: c.id === selected ? 'rgba(0,135,81,0.07)' : undefined,
                }}
              >
                {c.icon(24)}
                <span className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>
                  {c.label}
                  <span className="block text-xs font-normal" style={{ color: 'var(--muted)' }}>
                    {c.fullName}
                  </span>
                </span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

// ── Main ───────────────────────────────────────────────────────
export default function SellCrypto() {
  const { address, isConnected, chainId: walletChainId } = useAccount()
  const { switchChain } = useSwitchChain()

  const [selectedCoin, setSelectedCoin] = useState<CoinId>('usdc')
  const [amount, setAmount] = useState('')
  const [showOrder, setShowOrder] = useState(false)
  const [ratesTime, setRatesTime] = useState<string>(
    () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  )

  const isWrongChain = isConnected && walletChainId !== TARGET_CHAIN_ID

  const usdcFact = getUsdc(TARGET_CHAIN_ID)
  const { data: usdcRaw, isLoading: balanceLoading } = useReadContract({
    address: usdcFact?.address as `0x${string}`,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    chainId: TARGET_CHAIN_ID,
    query: { enabled: !!address && !!usdcFact && selectedCoin === 'usdc' },
  })

  const usdcBalance = usdcRaw != null
    ? Amount.fromRaw(usdcRaw, usdcDecimalsFor(TARGET_CHAIN_ID))
    : null
  const formattedBalance = usdcBalance ? usdcBalance.toFixed(2) : null

  const coin = COINS.find((c) => c.id === selectedCoin)!
  const rate = NGN_RATES[selectedCoin]
  const parsedAmount = parseFloat(amount) || 0
  const nairaEquivalent = parsedAmount * rate

  const refreshTime = useCallback(() => {
    setRatesTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }))
  }, [])

  useEffect(() => {
    const id = setInterval(refreshTime, 30_000)
    return () => clearInterval(id)
  }, [refreshTime])

  const isAmountValid = parsedAmount > 0
  const canProceed = isConnected && !isWrongChain && isAmountValid

  return (
    <div
      className="min-h-dvh"
      style={{ background: 'var(--bg-gradient)' }}
    >
      {/* ── Nav bar ── */}
      <nav
        className="sticky top-0 z-10 px-4 py-3"
        style={{
          background: 'rgba(255,255,255,0.80)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(18,45,69,0.07)',
        }}
      >
        <div className="mx-auto flex max-w-md items-center justify-between">
          <div className="flex items-center gap-2.5">
            {/* Logo mark */}
            <div
              className="flex size-8 items-center justify-center rounded-xl text-sm font-black text-white"
              style={{ background: 'var(--naira-green)' }}
            >
              M
            </div>
            <div>
              <p className="display text-base font-bold leading-none" style={{ color: 'var(--ink)' }}>
                MeekHub
              </p>
              <p className="text-[10px]" style={{ color: 'var(--muted)' }}>
                Crypto → Naira
              </p>
            </div>
          </div>

          <ConnectKitButton.Custom>
            {({ isConnected: ck, show, address: ckAddr }) => (
              <button
                onClick={show}
                className="flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold transition-all hover:scale-[1.02] active:scale-[0.98]"
                style={{
                  background: ck ? 'var(--naira-green-light)' : 'var(--accent)',
                  color: ck ? 'var(--naira-green)' : '#fff',
                  border: ck ? '1px solid rgba(0,135,81,0.18)' : 'none',
                }}
              >
                <Wallet className="size-3.5" />
                {ck ? `${ckAddr?.slice(0, 6)}…${ckAddr?.slice(-4)}` : 'Connect Wallet'}
              </button>
            )}
          </ConnectKitButton.Custom>
        </div>
      </nav>

      {/* ── Page body ── */}
      <div className="mx-auto max-w-md px-4 pb-10 pt-5">

        {/* Rate pill */}
        <div className="mb-4 flex items-center justify-between rounded-2xl px-4 py-2.5" style={field}>
          <div className="flex items-center gap-1.5">
            <span
              className="size-1.5 rounded-full animate-pulse"
              style={{ background: 'var(--naira-green)', display: 'inline-block' }}
            />
            <span className="text-xs" style={{ color: 'var(--muted)' }}>Live rate</span>
            <span className="mono text-xs font-semibold tabular-nums" style={{ color: 'var(--ink)' }}>
              1 {coin.label} = ₦{rate.toLocaleString()}
            </span>
          </div>
          <button
            onClick={refreshTime}
            className="flex items-center gap-1 text-[11px] transition-opacity hover:opacity-60"
            style={{ color: 'var(--subtle)' }}
          >
            <RefreshCw className="size-3" />
            {ratesTime}
          </button>
        </div>

        {/* ── Main swap card ── */}
        <div className="rounded-3xl p-5" style={card}>

          {/* YOU SELL row */}
          <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-[0.08em]" style={{ color: 'var(--muted)' }}>
            You Sell
          </p>
          <div className="rounded-2xl p-4" style={field}>
            <div className="flex items-start justify-between">
              <CoinPicker selected={selectedCoin} onSelect={setSelectedCoin} />
              <div className="text-right">
                <input
                  inputMode="decimal"
                  value={amount}
                  onChange={(e) => {
                    const v = e.target.value.replace(/[^0-9.]/g, '')
                    if (v === '' || /^\d*\.?\d*$/.test(v)) setAmount(v)
                  }}
                  placeholder="0.00"
                  className="display w-full bg-transparent text-right text-3xl font-bold tabular-nums outline-none placeholder:text-slate-300"
                  style={{ color: 'var(--ink)', maxWidth: '160px' }}
                />
                {isConnected && selectedCoin === 'usdc' && (
                  <button
                    disabled={!formattedBalance}
                    onClick={() => formattedBalance && setAmount(formattedBalance)}
                    className="mt-0.5 text-[11px] font-medium disabled:opacity-40"
                    style={{ color: 'var(--accent-hover)' }}
                  >
                    {balanceLoading ? 'Loading…' : formattedBalance ? `Bal: ${formattedBalance} · Max` : '—'}
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Arrow divider */}
          <div className="flex items-center gap-3 py-3">
            <div className="h-px flex-1" style={{ background: 'var(--border)' }} />
            <div
              className="flex size-8 items-center justify-center rounded-xl"
              style={{ background: 'var(--naira-green-light)' }}
            >
              <ArrowDown className="size-4" style={{ color: 'var(--naira-green)' }} />
            </div>
            <div className="h-px flex-1" style={{ background: 'var(--border)' }} />
          </div>

          {/* YOU RECEIVE row */}
          <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-[0.08em]" style={{ color: 'var(--muted)' }}>
            You Receive
          </p>
          <div className="rounded-2xl p-4" style={field}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span
                  className="flex size-7 items-center justify-center rounded-full text-xs font-black text-white"
                  style={{ background: 'var(--naira-green)' }}
                >
                  ₦
                </span>
                <span className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>
                  Naira
                  <span className="block text-[10px] font-normal" style={{ color: 'var(--muted)' }}>
                    Nigerian Naira
                  </span>
                </span>
              </div>
              <span
                className="display text-3xl font-bold tabular-nums"
                style={{ color: parsedAmount > 0 ? 'var(--naira-green)' : 'var(--subtle)' }}
              >
                {parsedAmount > 0
                  ? nairaEquivalent.toLocaleString('en-NG', { maximumFractionDigits: 0 })
                  : '—'}
              </span>
            </div>
          </div>

          {/* Chain warning */}
          {isWrongChain && (
            <button
              onClick={() => switchChain({ chainId: TARGET_CHAIN_ID })}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold"
              style={{ background: '#ba2b4c12', color: 'var(--danger)', border: '1px solid #ba2b4c28' }}
            >
              <AlertTriangle className="size-4" />
              Switch to Arc Testnet
            </button>
          )}

          {/* CTA */}
          {!isWrongChain && (
            <button
              disabled={!canProceed}
              onClick={() => setShowOrder(true)}
              className="mt-3 w-full rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-40"
              style={{ background: 'var(--accent)' }}
            >
              {!isConnected
                ? 'Connect Wallet to Sell'
                : !isAmountValid
                ? 'Enter an Amount'
                : `Sell ${amount} ${coin.label} → NGN`}
            </button>
          )}

          {/* Inline trust row */}
          <div
            className="mt-4 grid grid-cols-3 divide-x rounded-2xl py-2.5"
            style={{
              background: 'rgba(18,45,69,0.025)',
              borderRadius: '14px',
              border: '1px solid rgba(18,45,69,0.06)',
            }}
          >
            {[
              { icon: <ShieldCheck className="size-3.5" />, label: 'Secured' },
              { icon: <Zap className="size-3.5" />, label: 'Best Rates' },
              { icon: <Clock className="size-3.5" />, label: '24/7 Support' },
            ].map((b, i) => (
              <div
                key={b.label}
                className="flex flex-col items-center gap-0.5 py-1"
                style={{ borderLeft: i > 0 ? '1px solid rgba(18,45,69,0.08)' : undefined }}
              >
                <span style={{ color: 'var(--naira-green)' }}>{b.icon}</span>
                <span className="text-[10px] font-medium" style={{ color: 'var(--ink-2)' }}>
                  {b.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* ── Accepted coins ── */}
        <div className="mt-3 rounded-2xl px-4 py-3.5" style={card}>
          <p className="mb-2.5 text-[11px] font-semibold uppercase tracking-[0.08em]" style={{ color: 'var(--muted)' }}>
            We Accept
          </p>
          <div className="flex flex-wrap gap-2">
            {COINS.map((c) => {
              const active = c.id === selectedCoin
              return (
                <button
                  key={c.id}
                  onClick={() => setSelectedCoin(c.id)}
                  className="flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold transition-all hover:scale-[1.03]"
                  style={{
                    background: active ? 'var(--accent)' : 'rgba(18,45,69,0.05)',
                    color: active ? '#fff' : 'var(--ink)',
                    border: active ? 'none' : '1px solid rgba(18,45,69,0.07)',
                  }}
                >
                  {c.icon(18)}
                  {c.label}
                </button>
              )
            })}
          </div>
        </div>

        <p className="mt-4 text-center text-[11px]" style={{ color: 'var(--subtle)' }}>
          Testnet demo — no real funds moved
        </p>
      </div>

      {showOrder && (
        <OrderSheet
          coin={coin}
          amount={amount}
          nairaAmount={nairaEquivalent}
          rate={rate}
          onClose={() => setShowOrder(false)}
        />
      )}
    </div>
  )
}
