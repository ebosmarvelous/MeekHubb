import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useWriteContract, useWaitForTransactionReceipt } from 'wagmi'
import { erc20Abi } from 'viem'
import {
  X,
  Loader2,
  CheckCircle2,
  Copy,
  ExternalLink,
  AlertCircle,
  Building2,
  Hash,
  ChevronDown,
  BadgeCheck,
} from 'lucide-react'
import { getUsdc, buildTxExplorerUrl } from '@/onchain-facts'
import { parseAmount } from '@/onchain-money'
import { NIGERIAN_BANKS } from '@/data/nigerian-banks'

const TARGET_CHAIN_ID = 5042002

// Replace with your actual treasury wallet before going to production
const TREASURY_ADDRESS = '0x5B12Ce46C7194aD57d143bC22847224047b1Ef42' as `0x${string}`

const springs = {
  sheet: { type: 'spring' as const, stiffness: 400, damping: 40 },
}

const spectral = 'linear-gradient(90deg, #008751 0%, #00b35a 50%, #4fc878 100%)'

const glass = {
  inner: {
    background: 'rgba(18,45,69,0.04)',
    border: '1px solid rgba(18,45,69,0.08)',
  } as React.CSSProperties,
}

type CoinData = { id: string; label: string; fullName: string; isUsdc: boolean }

interface Bank {
  id: number
  name: string
  code: string
}

interface OrderSheetProps {
  coin: CoinData
  amount: string
  nairaAmount: number
  rate: number
  onClose: () => void
}

type Step = 'details' | 'confirm' | 'paying' | 'success' | 'error'

// ── Bank selector ──────────────────────────────────────────────
function BankSelector({
  banks,
  value,
  onChange,
}: {
  banks: Bank[]
  value: string
  onChange: (code: string, name: string) => void
}) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const selected = banks.find((b) => b.code === value)
  const filtered = banks.filter((b) =>
    b.name.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div>
      <label className="mb-1 block text-xs font-semibold" style={{ color: 'var(--muted)' }}>
        Bank
      </label>
      <div className="relative">
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-sm font-medium"
          style={{ ...glass.inner, color: selected ? 'var(--ink)' : '#94a3b8' }}
        >
          <span className="flex items-center gap-2">
            <Building2 className="size-4" style={{ color: 'var(--subtle)' }} />
            {selected ? selected.name : 'Select your bank'}
          </span>
          <ChevronDown
            className="size-4 transition-transform"
            style={{
              color: 'var(--subtle)',
              transform: open ? 'rotate(180deg)' : undefined,
            }}
          />
        </button>

        {open && (
          <div
            className="absolute left-0 top-full z-30 mt-1 w-full overflow-hidden rounded-2xl"
            style={{
              background: 'rgba(255,255,255,0.97)',
              border: '1px solid rgba(18,45,69,0.10)',
              boxShadow: '0 8px 32px rgba(18,45,69,0.12)',
            }}
          >
            <div className="border-b p-2" style={{ borderColor: 'var(--border)' }}>
              <input
                autoFocus
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search bank..."
                className="w-full bg-transparent px-2 py-1.5 text-sm outline-none"
                style={{ color: 'var(--ink)' }}
              />
            </div>
            <div className="max-h-48 overflow-y-auto">
              {filtered.length === 0 ? (
                <p className="px-3 py-3 text-xs" style={{ color: 'var(--muted)' }}>
                  No banks found
                </p>
              ) : (
                filtered.map((b) => (
                  <button
                    key={b.code}
                    type="button"
                    onClick={() => {
                      onChange(b.code, b.name)
                      setOpen(false)
                      setSearch('')
                    }}
                    className="flex w-full items-center px-3 py-2.5 text-sm font-medium transition-colors hover:bg-black/5"
                    style={{ color: 'var(--ink)' }}
                  >
                    {b.name}
                  </button>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ── Main sheet ─────────────────────────────────────────────────
export default function OrderSheet({
  coin,
  amount,
  nairaAmount,
  rate,
  onClose,
}: OrderSheetProps) {
  const [step, setStep] = useState<Step>('details')

  // Bank + account fields — seeded immediately with the built-in list
  const [banks, setBanks] = useState<Bank[]>(NIGERIAN_BANKS)
  const [bankCode, setBankCode] = useState('')
  const [bankName, setBankName] = useState('')
  const [accountNumber, setAccountNumber] = useState('')
  const [accountName, setAccountName] = useState('')
  const [verifying, setVerifying] = useState(false)
  const [verifyError, setVerifyError] = useState('')

  // Payout state
  const [payoutError, setPayoutError] = useState('')
  const [transferCode, setTransferCode] = useState('')
  const [copied, setCopied] = useState(false)
  const [orderRef] = useState(() => `MEEK-${Date.now().toString(36).toUpperCase()}`)

  const usdcFact = getUsdc(TARGET_CHAIN_ID)
  const { writeContract, data: txHash, isPending, isError, error } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash: txHash })

  // Silently upgrade bank list from Paystack if API key is configured
  useEffect(() => {
    fetch('/api/banks')
      .then((r) => r.json())
      .then((data: Bank[]) => {
        if (Array.isArray(data) && data.length > 0) setBanks(data)
      })
      .catch(() => {/* keep built-in list on any error */})
  }, [])

  // Auto-verify account name when 10-digit NUBAN + bank selected
  useEffect(() => {
    if (accountNumber.length !== 10 || !bankCode) return
    setVerifying(true)
    setVerifyError('')
    setAccountName('')
    fetch('/api/verify-account', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ account_number: accountNumber, bank_code: bankCode }),
    })
      .then((r) => r.json())
      .then((d: { account_name?: string; error?: string }) => {
        if (d.account_name) setAccountName(d.account_name)
        else setVerifyError(d.error ?? 'Could not verify account')
      })
      .catch(() => setVerifyError('Network error — check your connection'))
      .finally(() => setVerifying(false))
  }, [accountNumber, bankCode])

  // Trigger NGN payout once the onchain tx is confirmed
  useEffect(() => {
    if (!isSuccess || step !== 'confirm') return
    setStep('paying')
    setPayoutError('')
    fetch('/api/payout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        account_number: accountNumber,
        bank_code: bankCode,
        account_name: accountName,
        amount_ngn: nairaAmount,
        coin: coin.label,
        tx_hash: txHash ?? '',
        order_ref: orderRef,
      }),
    })
      .then((r) => r.json())
      .then((d: { transfer_code?: string; error?: string }) => {
        if (d.transfer_code) {
          setTransferCode(d.transfer_code)
          setStep('success')
        } else {
          setPayoutError(d.error ?? 'Payout failed — contact support with ref ' + orderRef)
          setStep('error')
        }
      })
      .catch(() => {
        setPayoutError('Network error during payout — contact support with ref ' + orderRef)
        setStep('error')
      })
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSuccess])

  const canSubmitDetails =
    bankCode && accountNumber.length === 10 && accountName && !verifying && !verifyError

  function handleConfirm() {
    if (!usdcFact || coin.id !== 'usdc') {
      // Non-USDC: skip onchain step, go straight to payout (extend for real flows)
      setStep('paying')
      triggerPayout(undefined)
      return
    }
    const parsed = parseAmount(TARGET_CHAIN_ID, amount)
    writeContract({
      address: usdcFact.address as `0x${string}`,
      abi: erc20Abi,
      functionName: 'transfer',
      args: [TREASURY_ADDRESS, parsed.raw],
      chainId: TARGET_CHAIN_ID,
    })
  }

  function triggerPayout(hash: string | undefined) {
    fetch('/api/payout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        account_number: accountNumber,
        bank_code: bankCode,
        account_name: accountName,
        amount_ngn: nairaAmount,
        coin: coin.label,
        tx_hash: hash ?? '',
        order_ref: orderRef,
      }),
    })
      .then((r) => r.json())
      .then((d: { transfer_code?: string; error?: string }) => {
        if (d.transfer_code) {
          setTransferCode(d.transfer_code)
          setStep('success')
        } else {
          setPayoutError(d.error ?? 'Payout failed — contact support with ref ' + orderRef)
          setStep('error')
        }
      })
      .catch(() => {
        setPayoutError('Network error during payout — contact support with ref ' + orderRef)
        setStep('error')
      })
  }

  const txUrl = txHash ? buildTxExplorerUrl(TARGET_CHAIN_ID, txHash) : null

  function handleCopy(text: string) {
    navigator.clipboard.writeText(text).catch(() => {})
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 flex items-end justify-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      >
        <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" />
        <motion.section
          className="relative w-full max-w-md overflow-hidden rounded-t-3xl"
          style={{
            background: 'rgba(255,255,255,0.95)',
            backdropFilter: 'blur(40px) saturate(200%)',
            WebkitBackdropFilter: 'blur(40px) saturate(200%)',
          }}
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={springs.sheet}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="h-1" style={{ background: spectral }} />
          <div className="flex justify-center pt-3 pb-1">
            <div className="h-1 w-10 rounded-full bg-black/10" />
          </div>
          <button
            onClick={onClose}
            className="absolute right-4 top-5 rounded-full p-1.5 transition-colors hover:bg-black/5"
            style={{ color: 'var(--muted)' }}
          >
            <X className="size-4" />
          </button>

          <div className="px-5 pb-8 pt-2">
            {/* Order summary */}
            <div
              className="mb-4 flex items-center justify-between rounded-2xl px-4 py-3"
              style={glass.inner}
            >
              <div>
                <p className="text-xs" style={{ color: 'var(--muted)' }}>Selling</p>
                <p className="display text-lg font-bold tabular-nums" style={{ color: 'var(--ink)' }}>
                  {amount} {coin.label}
                </p>
              </div>
              <div className="text-right">
                <p className="text-xs" style={{ color: 'var(--muted)' }}>You receive</p>
                <p
                  className="display text-lg font-bold tabular-nums"
                  style={{ color: 'var(--naira-green)' }}
                >
                  ₦{nairaAmount.toLocaleString('en-NG', { maximumFractionDigits: 0 })}
                </p>
              </div>
            </div>

            {/* ── STEP: Bank details ── */}
            {step === 'details' && (
              <div className="space-y-3">
                <h2 className="display text-lg font-bold" style={{ color: 'var(--ink)' }}>
                  Bank Details
                </h2>

                <BankSelector
                  banks={banks}
                  value={bankCode}
                  onChange={(code, name) => { setBankCode(code); setBankName(name) }}
                />

                <div>
                  <label className="mb-1 block text-xs font-semibold" style={{ color: 'var(--muted)' }}>
                    Account Number
                  </label>
                  <div className="flex items-center gap-2 rounded-xl px-3 py-2.5" style={glass.inner}>
                    <Hash className="size-4" style={{ color: 'var(--subtle)' }} />
                    <input
                      inputMode="numeric"
                      value={accountNumber}
                      onChange={(e) => {
                        const digits = e.target.value.replace(/\D/g, '').slice(0, 10)
                        setAccountNumber(digits)
                        setAccountName('')
                        setVerifyError('')
                      }}
                      placeholder="10-digit NUBAN"
                      className="flex-1 bg-transparent text-sm font-medium outline-none placeholder:text-slate-300"
                      style={{ color: 'var(--ink)' }}
                    />
                    {verifying && <Loader2 className="size-4 animate-spin" style={{ color: 'var(--muted)' }} />}
                  </div>
                </div>

                {/* Auto-resolved account name */}
                {accountName && (
                  <div
                    className="flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold"
                    style={{ background: 'var(--naira-green-light)', color: 'var(--naira-green)' }}
                  >
                    <BadgeCheck className="size-4 shrink-0" />
                    {accountName}
                  </div>
                )}
                {verifyError && (
                  <div
                    className="flex items-center gap-2 rounded-xl px-3 py-2 text-xs"
                    style={{ background: '#ba2b4c11', color: 'var(--danger)' }}
                  >
                    <AlertCircle className="size-3.5 shrink-0" />
                    {verifyError}
                  </div>
                )}

                <div
                  className="flex items-start gap-2 rounded-xl px-3 py-2.5 text-xs"
                  style={{ background: 'var(--naira-green-light)', color: 'var(--naira-green)' }}
                >
                  <AlertCircle className="mt-0.5 size-3.5 shrink-0" />
                  NGN is sent instantly via Paystack once your crypto transfer confirms.
                </div>

                <button
                  disabled={!canSubmitDetails}
                  onClick={() => setStep('confirm')}
                  className="w-full rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-40"
                  style={{ background: 'var(--accent)' }}
                >
                  Continue
                </button>
              </div>
            )}

            {/* ── STEP: Confirm ── */}
            {step === 'confirm' && (
              <div className="space-y-3">
                <h2 className="display text-lg font-bold" style={{ color: 'var(--ink)' }}>
                  Confirm Order
                </h2>

                <div className="space-y-2 rounded-2xl p-3" style={glass.inner}>
                  {[
                    { label: 'Selling', value: `${amount} ${coin.label}` },
                    { label: 'Rate', value: `₦${rate.toLocaleString()} / ${coin.label}` },
                    { label: 'You receive', value: `₦${nairaAmount.toLocaleString('en-NG', { maximumFractionDigits: 0 })}` },
                    { label: 'Bank', value: bankName },
                    { label: 'Account name', value: accountName },
                    { label: 'Account no.', value: accountNumber },
                  ].map((row) => (
                    <div key={row.label} className="flex justify-between text-sm">
                      <span style={{ color: 'var(--muted)' }}>{row.label}</span>
                      <span className="font-semibold" style={{ color: 'var(--ink)' }}>
                        {row.value}
                      </span>
                    </div>
                  ))}
                </div>

                {isError && (
                  <div className="rounded-xl px-3 py-2 text-xs" style={{ background: '#ba2b4c11', color: 'var(--danger)' }}>
                    {error?.message?.includes('user rejected')
                      ? 'Transaction cancelled.'
                      : 'Transaction failed. Please try again.'}
                  </div>
                )}

                <div className="flex gap-2">
                  <button
                    onClick={() => setStep('details')}
                    disabled={isPending || isConfirming}
                    className="flex-1 rounded-2xl border py-3.5 text-sm font-semibold transition-colors hover:bg-black/5 disabled:opacity-40"
                    style={{ borderColor: 'var(--border)', color: 'var(--ink)' }}
                  >
                    Back
                  </button>
                  <button
                    disabled={isPending || isConfirming}
                    onClick={handleConfirm}
                    className="flex-[2] flex items-center justify-center gap-2 rounded-2xl py-3.5 text-sm font-semibold text-white disabled:opacity-60"
                    style={{ background: 'var(--accent)' }}
                  >
                    {isPending ? (
                      <><Loader2 className="size-4 animate-spin" /> Confirm in wallet...</>
                    ) : isConfirming ? (
                      <><Loader2 className="size-4 animate-spin" /> Confirming...</>
                    ) : (
                      'Send & Sell'
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* ── STEP: Paying ── */}
            {step === 'paying' && (
              <div className="space-y-4 py-4 text-center">
                <div
                  className="mx-auto flex size-16 items-center justify-center rounded-full"
                  style={{ background: 'var(--naira-green-light)' }}
                >
                  <Loader2 className="size-8 animate-spin" style={{ color: 'var(--naira-green)' }} />
                </div>
                <h2 className="display text-lg font-bold" style={{ color: 'var(--ink)' }}>
                  Sending NGN...
                </h2>
                <p className="text-sm" style={{ color: 'var(--muted)' }}>
                  Crypto confirmed. Initiating bank transfer via Paystack.
                </p>
              </div>
            )}

            {/* ── STEP: Success ── */}
            {step === 'success' && (
              <div className="space-y-4 text-center">
                <div
                  className="mx-auto flex size-16 items-center justify-center rounded-full"
                  style={{ background: 'var(--naira-green-light)' }}
                >
                  <CheckCircle2 className="size-8" style={{ color: 'var(--naira-green)' }} />
                </div>
                <div>
                  <h2 className="display text-xl font-bold" style={{ color: 'var(--ink)' }}>
                    Money Sent!
                  </h2>
                  <p className="mt-1 text-sm" style={{ color: 'var(--muted)' }}>
                    <strong>
                      ₦{nairaAmount.toLocaleString('en-NG', { maximumFractionDigits: 0 })}
                    </strong>{' '}
                    is on its way to <strong>{accountName}</strong> at{' '}
                    <strong>{bankName}</strong>.
                  </p>
                </div>

                {txUrl && (
                  <a
                    href={txUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-medium"
                    style={{ color: 'var(--accent-hover)' }}
                  >
                    View crypto tx on ArcScan <ExternalLink className="size-3" />
                  </a>
                )}

                <div className="space-y-2 rounded-2xl p-3 text-left" style={glass.inner}>
                  {transferCode && (
                    <div className="flex justify-between text-xs">
                      <span style={{ color: 'var(--muted)' }}>Paystack ref</span>
                      <span className="mono font-medium" style={{ color: 'var(--ink)' }}>{transferCode}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-xs">
                    <span style={{ color: 'var(--muted)' }}>Order ref</span>
                    <span className="mono font-medium" style={{ color: 'var(--ink)' }}>{orderRef}</span>
                  </div>
                </div>

                <button
                  onClick={() => handleCopy(`${orderRef}${transferCode ? ' / ' + transferCode : ''}`)}
                  className="flex w-full items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold"
                  style={{ background: 'var(--naira-green-light)', color: 'var(--naira-green)' }}
                >
                  <Copy className="size-4" />
                  {copied ? 'Copied!' : 'Copy References'}
                </button>

                <button
                  onClick={onClose}
                  className="w-full rounded-2xl py-3.5 text-sm font-semibold text-white"
                  style={{ background: 'var(--accent)' }}
                >
                  Done
                </button>
              </div>
            )}

            {/* ── STEP: Error ── */}
            {step === 'error' && (
              <div className="space-y-4 text-center">
                <div
                  className="mx-auto flex size-16 items-center justify-center rounded-full"
                  style={{ background: '#ba2b4c11' }}
                >
                  <AlertCircle className="size-8" style={{ color: 'var(--danger)' }} />
                </div>
                <div>
                  <h2 className="display text-lg font-bold" style={{ color: 'var(--ink)' }}>
                    Payout Failed
                  </h2>
                  <p className="mt-1 text-sm" style={{ color: 'var(--muted)' }}>
                    {payoutError}
                  </p>
                </div>
                {txUrl && (
                  <a
                    href={txUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-medium"
                    style={{ color: 'var(--accent-hover)' }}
                  >
                    Crypto tx confirmed on ArcScan <ExternalLink className="size-3" />
                  </a>
                )}
                <p className="text-xs" style={{ color: 'var(--muted)' }}>
                  Your crypto was received. Quote your order ref when contacting support:{' '}
                  <span className="mono font-semibold" style={{ color: 'var(--ink)' }}>{orderRef}</span>
                </p>
                <button
                  onClick={() => handleCopy(orderRef)}
                  className="flex w-full items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold"
                  style={{ background: '#ba2b4c11', color: 'var(--danger)' }}
                >
                  <Copy className="size-4" />
                  {copied ? 'Copied!' : 'Copy Order Ref'}
                </button>
                <button
                  onClick={onClose}
                  className="w-full rounded-2xl border py-3.5 text-sm font-semibold"
                  style={{ borderColor: 'var(--border)', color: 'var(--ink)' }}
                >
                  Close
                </button>
              </div>
            )}
          </div>
        </motion.section>
      </motion.div>
    </AnimatePresence>
  )
}
