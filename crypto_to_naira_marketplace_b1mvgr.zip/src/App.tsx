import SellCrypto from './components/SellCrypto'

export default function App() {
  return <SellCrypto />
}
